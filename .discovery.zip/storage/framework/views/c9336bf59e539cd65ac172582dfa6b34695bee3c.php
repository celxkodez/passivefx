Greetings!

<?php echo $demo->message; ?>

 
 
 
Kind regards,

PassiveFX Invest.