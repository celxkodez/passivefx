<?php

namespace Stripe\Error;

class Api extends Base
{
}
