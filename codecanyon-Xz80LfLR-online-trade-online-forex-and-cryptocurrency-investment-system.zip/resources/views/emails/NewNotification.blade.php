Greetings!

{!! $demo->message !!}
 
 
 
Kind regards,

{{ $demo->sender }}.