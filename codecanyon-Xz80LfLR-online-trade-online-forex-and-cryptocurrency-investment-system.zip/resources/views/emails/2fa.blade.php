Below is your 2FA authentication code.

{!! $demo->message !!}
 
This mail was sent to authorize a login to your account. 
 
Kind regards,

{{ $demo->sender }}.